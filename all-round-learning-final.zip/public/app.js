const state = {
  token: localStorage.getItem('arl_token'),
  user: JSON.parse(localStorage.getItem('arl_user') || 'null'),
  loginMode: false,
  currentQuiz: null
};

const questions = {
  Mathematics: [
    { q: 'What is 12 × 8?', options: ['86', '96', '108', '112'], answer: 1 },
    { q: 'Solve: 45 ÷ 5', options: ['7', '8', '9', '10'], answer: 2 },
    { q: 'What is 15% of 200?', options: ['20', '25', '30', '35'], answer: 2 }
  ],
  English: [
    { q: 'Which word is a noun?', options: ['Quickly', 'Beautiful', 'Teacher', 'Run'], answer: 2 },
    { q: 'Choose the correct sentence.', options: ['She go home.', 'She goes home.', 'She going home.', 'She gone home.'], answer: 1 },
    { q: 'What is the opposite of “ancient”?', options: ['Old', 'Modern', 'Historic', 'Past'], answer: 1 }
  ],
  Literature: [
    { q: 'A comparison using “like” or “as” is called what?', options: ['Metaphor', 'Simile', 'Irony', 'Pun'], answer: 1 },
    { q: 'The main character in a story is commonly called the…', options: ['Protagonist', 'Narrator', 'Audience', 'Editor'], answer: 0 },
    { q: 'A struggle between opposing forces is called…', options: ['Setting', 'Conflict', 'Tone', 'Mood'], answer: 1 }
  ],
  Government: [
    { q: 'Which arm of government makes laws?', options: ['Executive', 'Legislature', 'Judiciary', 'Civil service'], answer: 1 },
    { q: 'The supreme law of a state is its…', options: ['Manifesto', 'Constitution', 'Budget', 'Decree'], answer: 1 },
    { q: 'Democracy means government by…', options: ['One ruler', 'The military', 'The people', 'Judges'], answer: 2 }
  ],
  Economics: [
    { q: 'The basic economic problem is…', options: ['Scarcity', 'Inflation', 'Taxation', 'Banking'], answer: 0 },
    { q: 'A sustained rise in the general price level is…', options: ['Deflation', 'Inflation', 'Subsidy', 'Surplus'], answer: 1 },
    { q: 'Demand is generally the quantity consumers are willing and able to…', options: ['Produce', 'Sell', 'Buy', 'Tax'], answer: 2 }
  ],
  Civic: [
    { q: 'A citizen’s right to vote is known as…', options: ['Franchise', 'Immunity', 'Diplomacy', 'Petition'], answer: 0 },
    { q: 'Which promotes national unity?', options: ['Tolerance', 'Discrimination', 'Violence', 'Corruption'], answer: 0 },
    { q: 'The rule of law means…', options: ['Leaders are above the law', 'Everyone is subject to the law', 'Only citizens obey laws', 'Courts make all policies'], answer: 1 }
  ]
};

function showPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById(id).classList.add('active');

  if (id === 'quiz') renderQuizHome();
  if (id === 'leaderboard') loadLeaderboard();
  if (id === 'profile') loadProfile();
}

function toast(message) {
  const el = document.getElementById('toast');
  el.textContent = message;
  el.style.display = 'block';
  setTimeout(() => el.style.display = 'none', 2500);
}

function toggleAuth() {
  state.loginMode = !state.loginMode;
  document.getElementById('authTitle').textContent = state.loginMode ? 'Welcome back' : 'Create your account';
  document.getElementById('authSubtitle').textContent = state.loginMode ? 'Log in to continue learning.' : 'Start your learning journey.';
  document.getElementById('age').style.display = state.loginMode ? 'none' : 'block';
  document.getElementById('switchAuth').textContent = state.loginMode
    ? 'Need an account? Register'
    : 'Already have an account? Log in';
  document.getElementById('authMessage').textContent = '';
}

async function api(url, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;

  const response = await fetch(url, { ...options, headers });
  const data = await response.json().catch(() => ({}));

  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}

document.getElementById('authForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  const age = document.getElementById('age').value;

  try {
    const endpoint = state.loginMode ? '/api/auth/login' : '/api/auth/register';
    const body = state.loginMode ? { username, password } : { username, age, password };
    const data = await api(endpoint, { method: 'POST', body: JSON.stringify(body) });

    state.token = data.token;
    state.user = { id: data.userId, username: data.username, age: data.age };
    localStorage.setItem('arl_token', state.token);
    localStorage.setItem('arl_user', JSON.stringify(state.user));

    toast(`Welcome, ${data.username}!`);
    showPage('quiz');
  } catch (err) {
    document.getElementById('authMessage').textContent = err.message;
  }
});

function renderQuizHome() {
  const box = document.getElementById('quizBox');

  if (!state.user) {
    box.innerHTML = `<h3>Log in to play</h3><p>Create an account or log in before submitting quiz results.</p>
      <button class="primary" onclick="showPage('auth')">Log in / Register</button>`;
    return;
  }

  document.getElementById('quizUser').textContent = `Playing as ${state.user.username}`;

  box.innerHTML = `<h3>Choose a subject</h3>
    <p>Select a subject to begin a short practice quiz.</p>
    <div class="subjects">
      ${Object.keys(questions).map(s => `<button class="subject" onclick="startQuiz('${s}')">${s}</button>`).join('')}
    </div>`;
}

function startQuiz(subject) {
  state.currentQuiz = { subject, index: 0, score: 0, started: Date.now() };
  renderQuestion();
}

function renderQuestion() {
  const quiz = state.currentQuiz;
  const item = questions[quiz.subject][quiz.index];

  document.getElementById('quizBox').innerHTML = `
    <p class="eyebrow">${quiz.subject.toUpperCase()} • QUESTION ${quiz.index + 1}/${questions[quiz.subject].length}</p>
    <h2>${item.q}</h2>
    <div class="quiz-options">
      ${item.options.map((option, i) => `<button class="option" onclick="answerQuestion(${i})">${String.fromCharCode(65+i)}. ${option}</button>`).join('')}
    </div>`;
}

async function answerQuestion(choice) {
  const quiz = state.currentQuiz;
  const item = questions[quiz.subject][quiz.index];

  if (choice === item.answer) quiz.score += 1;
  quiz.index += 1;

  if (quiz.index < questions[quiz.subject].length) {
    renderQuestion();
    return;
  }

  const percent = Math.round((quiz.score / questions[quiz.subject].length) * 100);
  const time = Math.round((Date.now() - quiz.started) / 1000);

  try {
    await api('/api/quiz/submit', {
      method: 'POST',
      body: JSON.stringify({
        subject: quiz.subject,
        score: percent,
        difficulty: 'practice',
        time
      })
    });
  } catch (err) {
    toast(err.message);
  }

  document.getElementById('quizBox').innerHTML = `
    <h2>Quiz complete 🎉</h2>
    <p>You scored <strong>${quiz.score}/${questions[quiz.subject].length}</strong> (${percent}%).</p>
    <p>Time: ${time} seconds.</p>
    <button class="primary" onclick="renderQuizHome()">Choose another quiz</button>`;
}

async function loadLeaderboard() {
  const body = document.getElementById('leaderboardBody');
  body.innerHTML = '<tr><td colspan="4">Loading…</td></tr>';

  try {
    const rows = await api('/api/leaderboard');
    body.innerHTML = rows.length
      ? rows.map(r => `<tr><td>#${r.rank}</td><td>${escapeHtml(r.name)}</td><td>${r.age}</td><td>${r.score}</td></tr>`).join('')
      : '<tr><td colspan="4">No scores yet.</td></tr>';
  } catch (err) {
    body.innerHTML = `<tr><td colspan="4">${escapeHtml(err.message)}</td></tr>`;
  }
}

async function loadProfile() {
  const box = document.getElementById('profileBox');

  if (!state.user) {
    box.innerHTML = `<h3>You are not logged in.</h3><button class="primary" onclick="showPage('auth')">Log in / Register</button>`;
    return;
  }

  try {
    const user = await api('/api/user/me');
    box.innerHTML = `
      <h2>${escapeHtml(user.username)}</h2>
      <div class="stats">
        <div class="stat"><span>Points</span><b>${user.totalPoints}</b></div>
        <div class="stat"><span>Quizzes</span><b>${user.gamesPlayed}</b></div>
        <div class="stat"><span>Age</span><b>${user.age}</b></div>
      </div>
      <button class="secondary" onclick="logout()">Log out</button>`;
  } catch (err) {
    box.innerHTML = `<p>${escapeHtml(err.message)}</p>`;
  }
}

function logout() {
  localStorage.removeItem('arl_token');
  localStorage.removeItem('arl_user');
  state.token = null;
  state.user = null;
  toast('Logged out.');
  showPage('home');
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
  }[c]));
}

showPage('home');
