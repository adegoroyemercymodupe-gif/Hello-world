# All Round Learning

A simple educational quiz platform with:
- user registration and login
- SQLite database
- quiz scoring
- leaderboard
- achievements database
- multiplayer-room API
- responsive browser frontend

## Requirements

Install Node.js (LTS).

## Setup

Open a terminal inside this folder:

```bash
npm install
```

Create `.env` from `.env.example` and change `JWT_SECRET`.

Then initialize the database:

```bash
npm run init-db
```

Start the app:

```bash
npm start
```

Open:

http://localhost:5000

For development:

```bash
npm run dev
```

## Important

The included frontend contains working sample quizzes. The multiplayer database/API is prepared, but a real-time multiplayer game still needs a Socket.IO client/game flow.

Do not publish the development JWT secret. For a public deployment, use a strong environment variable and HTTPS.
