require('dotenv').config();

const express = require('express');
const cors = require('cors');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = Number(process.env.PORT) || 5000;
const SECRET_KEY = process.env.JWT_SECRET || 'dev-only-change-this-secret';

if (!process.env.JWT_SECRET) {
  console.warn('WARNING: JWT_SECRET is not set. Create a .env file before production use.');
}

app.use(cors());
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const db = new sqlite3.Database('./allroundlearning.db', (err) => {
  if (err) console.error('Database error:', err.message);
  else console.log('Connected to All Round Learning database');
});

db.run('PRAGMA foreign_keys = ON');

const run = (sql, params = []) => new Promise((resolve, reject) => {
  db.run(sql, params, function(err) {
    if (err) reject(err);
    else resolve(this);
  });
});

const get = (sql, params = []) => new Promise((resolve, reject) => {
  db.get(sql, params, (err, row) => {
    if (err) reject(err);
    else resolve(row);
  });
});

const all = (sql, params = []) => new Promise((resolve, reject) => {
  db.all(sql, params, (err, rows) => {
    if (err) reject(err);
    else resolve(rows);
  });
});

const signToken = (user) =>
  jwt.sign({ userId: user.id, username: user.username }, SECRET_KEY, { expiresIn: '24h' });

function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) return res.status(401).json({ error: 'Authentication required' });

  try {
    req.user = jwt.verify(token, SECRET_KEY);
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

function validUsername(username) {
  return typeof username === 'string' && /^[a-zA-Z0-9_]{3,20}$/.test(username);
}

function validPassword(password) {
  return typeof password === 'string' && password.length >= 6 && password.length <= 100;
}

app.get('/api/health', (req, res) => {
  res.json({ ok: true, message: 'All Round Learning API is running' });
});

app.post('/api/auth/register', async (req, res) => {
  try {
    const { username, age, password } = req.body;

    if (!validUsername(username)) {
      return res.status(400).json({ error: 'Username must be 3-20 letters, numbers, or underscores.' });
    }

    const numericAge = Number(age);
    if (!Number.isInteger(numericAge) || numericAge < 5 || numericAge > 120) {
      return res.status(400).json({ error: 'Please enter a valid age.' });
    }

    if (!validPassword(password)) {
      return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    const user = await run(
      'INSERT INTO users (username, age, password) VALUES (?, ?, ?)',
      [username.trim(), numericAge, hashedPassword]
    );

    const created = { id: user.lastID, username: username.trim() };
    res.status(201).json({
      token: signToken(created),
      userId: created.id,
      username: created.username,
      age: numericAge
    });
  } catch (err) {
    if (String(err.message).includes('UNIQUE constraint failed')) {
      return res.status(409).json({ error: 'That username is already taken.' });
    }
    console.error(err);
    res.status(500).json({ error: 'Registration failed.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await get('SELECT * FROM users WHERE username = ?', [username]);

    if (!user || !(await bcrypt.compare(password || '', user.password))) {
      return res.status(401).json({ error: 'Invalid username or password.' });
    }

    res.json({
      token: signToken(user),
      userId: user.id,
      username: user.username,
      age: user.age
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Login failed.' });
  }
});

app.post('/api/quiz/submit', auth, async (req, res) => {
  try {
    const { subject, score, difficulty, time } = req.body;
    const safeScore = Math.max(0, Math.min(100, Number(score) || 0));
    const safeTime = Math.max(0, Number(time) || 0);

    if (!subject || !difficulty) {
      return res.status(400).json({ error: 'Subject and difficulty are required.' });
    }

    const result = await run(
      'INSERT INTO quiz_results (user_id, subject, score, difficulty, time_taken) VALUES (?, ?, ?, ?, ?)',
      [req.user.userId, subject, safeScore, difficulty, safeTime]
    );

    await run(
      'UPDATE users SET total_points = total_points + ?, games_played = games_played + 1 WHERE id = ?',
      [safeScore, req.user.userId]
    );

    res.json({ success: true, resultId: result.lastID });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not save quiz result.' });
  }
});

app.get('/api/leaderboard', async (req, res) => {
  try {
    const rows = await all(
      'SELECT username, age, total_points FROM users ORDER BY total_points DESC, username ASC LIMIT 100'
    );

    res.json(rows.map((row, idx) => ({
      rank: idx + 1,
      name: row.username,
      age: row.age,
      score: row.total_points
    })));
  } catch (err) {
    res.status(500).json({ error: 'Could not load leaderboard.' });
  }
});

app.get('/api/user/me', auth, async (req, res) => {
  try {
    const user = await get(
      'SELECT id, username, age, total_points, games_played, created_at FROM users WHERE id = ?',
      [req.user.userId]
    );

    if (!user) return res.status(404).json({ error: 'User not found.' });

    res.json({
      id: user.id,
      username: user.username,
      age: user.age,
      totalPoints: user.total_points,
      gamesPlayed: user.games_played,
      joinedDate: user.created_at
    });
  } catch (err) {
    res.status(500).json({ error: 'Could not load profile.' });
  }
});

app.get('/api/user/:userId', auth, async (req, res) => {
  try {
    const user = await get(
      'SELECT id, username, age, total_points, games_played, created_at FROM users WHERE id = ?',
      [req.params.userId]
    );
    if (!user) return res.status(404).json({ error: 'User not found.' });

    res.json({
      id: user.id,
      username: user.username,
      age: user.age,
      totalPoints: user.total_points,
      gamesPlayed: user.games_played,
      joinedDate: user.created_at
    });
  } catch (err) {
    res.status(500).json({ error: 'Could not load user.' });
  }
});

app.post('/api/achievements/unlock', auth, async (req, res) => {
  try {
    const achievementId = Number(req.body.achievementId);
    if (!Number.isInteger(achievementId)) {
      return res.status(400).json({ error: 'Invalid achievement.' });
    }

    await run(
      'INSERT OR IGNORE INTO user_achievements (user_id, achievement_id) VALUES (?, ?)',
      [req.user.userId, achievementId]
    );

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Could not unlock achievement.' });
  }
});

app.get('/api/user/:userId/achievements', auth, async (req, res) => {
  try {
    const achievements = await all(
      `SELECT a.*
       FROM achievements a
       JOIN user_achievements ua ON a.id = ua.achievement_id
       WHERE ua.user_id = ?
       ORDER BY ua.unlocked_at DESC`,
      [req.params.userId]
    );
    res.json(achievements);
  } catch (err) {
    res.status(500).json({ error: 'Could not load achievements.' });
  }
});

function makeRoomCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

app.post('/api/multiplayer/create-room', auth, async (req, res) => {
  try {
    const { subject } = req.body;
    if (!subject) return res.status(400).json({ error: 'Subject is required.' });

    let roomCode;
    for (let i = 0; i < 10; i++) {
      const candidate = makeRoomCode();
      const existing = await get('SELECT id FROM multiplayer_rooms WHERE room_code = ?', [candidate]);
      if (!existing) {
        roomCode = candidate;
        break;
      }
    }

    if (!roomCode) return res.status(500).json({ error: 'Could not create a room.' });

    const room = await run(
      'INSERT INTO multiplayer_rooms (room_code, creator_id, subject) VALUES (?, ?, ?)',
      [roomCode, req.user.userId, subject]
    );

    await run(
      'INSERT INTO room_players (room_id, user_id, username) VALUES (?, ?, ?)',
      [room.lastID, req.user.userId, req.user.username]
    );

    res.status(201).json({ roomCode, roomId: room.lastID });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not create room.' });
  }
});

app.get('/api/multiplayer/room/:roomCode', auth, async (req, res) => {
  try {
    const room = await get(
      'SELECT * FROM multiplayer_rooms WHERE room_code = ?',
      [req.params.roomCode.toUpperCase()]
    );
    if (!room) return res.status(404).json({ error: 'Room not found.' });

    const players = await all(
      'SELECT id, user_id, username, score, position FROM room_players WHERE room_id = ? ORDER BY score DESC',
      [room.id]
    );

    res.json({ room, players });
  } catch (err) {
    res.status(500).json({ error: 'Could not load room.' });
  }
});

app.post('/api/multiplayer/join-room', auth, async (req, res) => {
  try {
    const roomId = Number(req.body.roomId);
    const room = await get('SELECT * FROM multiplayer_rooms WHERE id = ?', [roomId]);

    if (!room) return res.status(404).json({ error: 'Room not found.' });
    if (room.status !== 'waiting') return res.status(400).json({ error: 'This room is no longer accepting players.' });

    await run(
      'INSERT OR IGNORE INTO room_players (room_id, user_id, username) VALUES (?, ?, ?)',
      [roomId, req.user.userId, req.user.username]
    );

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Could not join room.' });
  }
});

app.post('/api/multiplayer/submit-score', auth, async (req, res) => {
  try {
    const roomId = Number(req.body.roomId);
    const score = Math.max(0, Number(req.body.score) || 0);

    await run(
      'UPDATE room_players SET score = ? WHERE room_id = ? AND user_id = ?',
      [score, roomId, req.user.userId]
    );

    const players = await all(
      'SELECT id, user_id, username, score, position FROM room_players WHERE room_id = ? ORDER BY score DESC',
      [roomId]
    );

    res.json({ players });
  } catch (err) {
    res.status(500).json({ error: 'Could not save multiplayer score.' });
  }
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`All Round Learning is running at http://localhost:${PORT}`);
});
