const sqlite3 = require('sqlite3').verbose();

const db = new sqlite3.Database('./allroundlearning.db');

const schema = `
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  age INTEGER NOT NULL CHECK(age >= 5 AND age <= 120),
  password TEXT NOT NULL,
  total_points INTEGER DEFAULT 0,
  games_played INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS quiz_results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  subject TEXT NOT NULL,
  score INTEGER NOT NULL,
  difficulty TEXT NOT NULL,
  time_taken INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS achievements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  description TEXT,
  icon TEXT,
  badge_type TEXT
);

CREATE TABLE IF NOT EXISTS user_achievements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  achievement_id INTEGER NOT NULL,
  unlocked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, achievement_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (achievement_id) REFERENCES achievements(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS multiplayer_rooms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_code TEXT UNIQUE NOT NULL,
  creator_id INTEGER NOT NULL,
  subject TEXT NOT NULL,
  status TEXT DEFAULT 'waiting',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (creator_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS room_players (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  username TEXT NOT NULL,
  score INTEGER DEFAULT 0,
  position INTEGER DEFAULT 0,
  UNIQUE(room_id, user_id),
  FOREIGN KEY (room_id) REFERENCES multiplayer_rooms(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
`;

const achievements = [
  ['First Step', 'Complete your first quiz', '🎯', 'bronze'],
  ['Quiz Master', 'Score 100% on any quiz', '🏆', 'gold'],
  ['Speed Demon', 'Complete a quiz in under 30 seconds', '⚡', 'silver'],
  ['Bookworm', 'Play 10 Literature quizzes', '📚', 'gold'],
  ['Math Genius', 'Get 5 Math questions right', '🔢', 'silver'],
  ['Civic Champion', 'Complete all Civic quizzes', '🏛️', 'gold'],
  ['English Expert', 'Master all English lessons', '✍️', 'silver'],
  ['Rising Star', 'Get into the top 10 leaderboard', '⭐', 'gold'],
  ['Puzzle Solver', 'Solve 5 puzzles correctly', '🧩', 'silver'],
  ['Strategy Master', 'Win 3 strategy challenges', '♟️', 'gold'],
  ['Social Butterfly', 'Play 5 multiplayer games', '👥', 'silver'],
  ['Consistent Learner', 'Play for 7 days in a row', '📅', 'gold'],
  ['Perfect Day', 'Get 100% on 3 quizzes in one day', '✨', 'platinum'],
  ['Collector', 'Unlock 10 achievements', '🎖️', 'gold']
];

db.serialize(() => {
  db.exec(schema, (err) => {
    if (err) {
      console.error('Database setup failed:', err.message);
      process.exitCode = 1;
      return;
    }

    const stmt = db.prepare(
      'INSERT OR IGNORE INTO achievements (name, description, icon, badge_type) VALUES (?, ?, ?, ?)'
    );

    for (const achievement of achievements) stmt.run(achievement);
    stmt.finalize((finalizeErr) => {
      if (finalizeErr) {
        console.error('Achievement setup failed:', finalizeErr.message);
        process.exitCode = 1;
      } else {
        console.log('Database initialized successfully.');
      }

      db.close((closeErr) => {
        if (closeErr) console.error('Database close error:', closeErr.message);
      });
    });
  });
});
